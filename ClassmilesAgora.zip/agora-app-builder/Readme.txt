
== Agora Appbuilder ==


Instructions to run the project:

1. Open a terminal inside this folder
2. Run - npm i && npm start (You need nodejs v14.x installed on you system)
3. Select install through the CLI menu
4. Build for any supported platform
